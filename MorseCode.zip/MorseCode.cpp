#include "MorseCode.h"

byte asciiToMorse[] = {0x78,0xcc,0x84,0x54,0x95,0xfd,0x7d,0x3d,0x1d,0x0d,0x05,0x85,0xc5,0xe5,0xf5,0xe0,0x8d,0x30,0x42,0x87,0xa7,0x83,
  0x01,0x27,0xc3,0x07,0x02,0x77,0xA3,0x47,0xc2,0x82,0xe3,0x67,0xd7,0x43,0x03,0x81,0x23,0x17,0x63,0x97,0xb7,0xc7,0x00};
//  ' , - . / 0      9  :  =  ?  A      Z (praznina)
  //0,1,2,3,4,5,...,14,15,16,17,18,...,43,44
  
static int pinM;
static bool message_sent = true, ms_flag = false;// 1 sent, 0 sending
static int speedInMillis = 200;//period of one dot
unsigned long timeForNext = 0;
byte maska3 = 0x03, maska7 = 0x07, maska1 = 0x80;
byte message[100];//ocekuju se manje poruke od 100 karaktera
char readCounter = 0, messageLen = 0;
char readCounterBit = 0, readToBit = 0, beginning = 1, pause_finished = 1;


MorseCode::MorseCode(int pin)
{
	pinM = pin;
	pinMode(pinM, OUTPUT);
    digitalWrite(pinM, LOW);
}
bool MorseCode::sendMessage(String msg)//vraca true ili false u zavisnosti da li ce se slati (jer se moze proslijediti string praznina)
{
	int spaces = 0;
	while(spaces < msg.length())//izbacivanje praznina sa pocetka
	{
		if(msg.charAt(spaces) == ' ' || msg.charAt(spaces) == '\n')
			spaces++;
		else
			break;
	}
	if(spaces >= msg.length())
		return false;
	messageLen = 0;
	while(spaces < msg.length())
	{
		message[messageLen] = asciiToMorse[byteToMorseByte(msg.charAt(spaces))];
		messageLen++;
		spaces++;
	}
	message_sent = false;
	return true;
}
bool MorseCode::setSpeedWpm(String speed)
{
	if(!message_sent)
		return false;
	
	int wpm = stringToIntPositive(speed);
	if(wpm == -1 || wpm > 80 || wpm == 0)
		return false;
	
	speedInMillis = 1200/wpm;
	return true;
}
bool MorseCode::messageSent()
{
	return message_sent;
}
bool MorseCode::messageSentFlag()
{
	if(ms_flag)
	{
		ms_flag = false;
		return true;
	}
	return false;
}
String MorseCode::getCurrentSpeedWpm()
{
	int s = 1200/speedInMillis;
	String pom = "";
	pom += String(s);
	return pom;
}
int MorseCode::stringToIntPositive(String s)
{
	if(s.length() == 0)
		return -1;
  int broj = 0, i = 0;
  while (i < s.length())
  {
    if (s.charAt(i) < '0' || s.charAt(i) > '9')
      return -1;
    broj = broj * 10 + s.charAt(i) - '0';
    i++;
  }
  return broj;
}
void MorseCode::sender()//periodicno ce se pozivati, i treba biti kratka vremenski
{
	//zabranjivanje prekida i uklanjanje intervala na funkcije?!
	if(message_sent)
		return;
	
	if(!beginning)
		if( millis() < timeForNext )//ako nije isteklo vrijeme
			return;
	
	if(!pause_finished)
	{
		pause_finished = 1;
		digitalWrite(pinM, LOW);
		int tempPause = speedInMillis;
		if(readCounterBit >= readToBit)
		{
			tempPause += speedInMillis*2;
			if(message[readCounter+1] == 0x00)//praznina
			{
				tempPause += speedInMillis*2;
				readCounter++;
			}
		}
		timeForNext += tempPause;
		return;
	}
	
	if(readCounterBit >= readToBit)
	{
		if(!beginning)
			readCounter++;
		
		if(readCounter >= messageLen)
		{
			message_sent = true; messageLen = 0; beginning = 1;
			readToBit = 0; readCounterBit = 0; readCounter = 0;
			pause_finished = 1; maska1 = 0x80; ms_flag = true;
			return;
		}
		if(message[readCounter] == 0x00)
		{
			digitalWrite(pinM, LOW);
            timeForNext += speedInMillis*5;
			return;
		}
		if(maska3 & message[readCounter])//znaci da se ne cita 6 bita
		{
			byte pom = ( maska7 & message[readCounter] );
			if( pom == maska7 )
				readToBit = 0x04;
			else
				readToBit = pom;
		}
		else
		{
			readToBit = 0x06;
		}
		readCounterBit = 0;
		maska1 = 0x80;
	}
	
	if(beginning)
	{
		timeForNext = millis();
		beginning = 0;
	}
	
	if(pause_finished)//citaj sljedecu 0 ili 1
	{
		pause_finished = 0;
		digitalWrite(pinM, HIGH);
		byte isDash = 0;//onda je dot
		if( (maska1 >> readCounterBit) & message[readCounter] )
			isDash = 1;
		timeForNext += speedInMillis + ( 2 * speedInMillis * isDash );
		readCounterBit++;
	}
}
byte MorseCode::byteToMorseByte(byte c)
{
	if(c >= 'A' && c <= 'Z')
		return c - 47;
	else if(c >= 'a' && c <= 'z')
		return c - 79;
	else if(c >= ',' && c <= ':')
		return c - 43;
	else if(c == 39)
		return 0;
	else if(c == '?')
		return 17;
	else if(c == '=')
		return 16;
	else 
		return 44; // praznina
}