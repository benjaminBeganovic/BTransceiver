#ifndef MorseCode_h
#define MorseCode_h

#include <inttypes.h>

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#include "pins_arduino.h"
#endif

class MorseCode{
	
public:
	MorseCode(int pin);
	~MorseCode() {}
	bool sendMessage(String msg);
	bool setSpeedWpm(String speed);
	bool messageSent();
	bool messageSentFlag();
	String getCurrentSpeedWpm();
	void sender();
private:
	int stringToIntPositive(String s);
	byte byteToMorseByte(byte c);
};

#endif
